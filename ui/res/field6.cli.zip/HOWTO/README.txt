Perl for Windows platform:
	http://www.activestate.com/activeperl

Install "ActivePerl" first;
In "cmd", exec "cpan install net-ssh2.ppd";
In "ppm", find & install "win32-serialport".